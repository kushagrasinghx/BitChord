package com.music.bitchord.data.settings

import com.music.bitchord.playback.smart.FilterTransitionVariant
import com.music.bitchord.playback.smart.PHRASE_BARS_LONG
import com.music.bitchord.playback.smart.PHRASE_BARS_SHORT

/**
 * How Automix decides the *shape* of a transition: when it starts and how long
 * it runs. Every entry maps onto a mode [com.music.bitchord.playback.smart.planTransition]
 * already implements, so choosing one never changes what the renderer is asked to do — only
 * which plan it is handed.
 *
 * A style that cannot be honoured for a pair (no trusted tempo, a track too short to fit the
 * phrase) falls back to [ADAPTIVE] for that pair rather than forcing a ragged mix.
 */
enum class AutomixMixStyle(
    /** `0` leaves the adaptive overlap in charge; otherwise a fixed phrase length in bars. */
    val phraseBars: Int,
    /** Confine the mix to the last and first 30 seconds of the pair. */
    val mixWindow: Boolean,
) {
    /** The planner decides length from how well the pair agrees. The default, and what shipped before. */
    ADAPTIVE(phraseBars = 0, mixWindow = false),

    /** A fixed 8-bar overlap, both edges snapped to the outgoing track's bars. */
    PHRASE_8(phraseBars = PHRASE_BARS_SHORT, mixWindow = false),

    /** A fixed 16-bar overlap: long, slow, club-style. */
    PHRASE_16(phraseBars = PHRASE_BARS_LONG, mixWindow = false),

    /** The adaptive plan, but never earlier than 30 seconds before the end or deeper than 30 seconds in. */
    WINDOWED(phraseBars = 0, mixWindow = true),
}

/**
 * The gesture Automix uses for a pair whose tempi are too far apart to beatmatch.
 * [AUTO] keeps the planner's own pick, which is stable per pair but varies from pair to pair;
 * any other entry forces that gesture for every such pair.
 */
enum class AutomixGesture(val variant: FilterTransitionVariant?) {
    AUTO(null),
    SWEEP(FilterTransitionVariant.SWEEP),
    BASS_HANDOFF(FilterTransitionVariant.BASS_HANDOFF),
    ECHO_RIDE(FilterTransitionVariant.ECHO_RIDE),
}
